self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9024c55f3439bc4439b959e9b7863f0b",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "fefdb2b32b93c1920708",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.e9feee97.chunk.css"
  },
  {
    "revision": "3f568962a26184cb47a0",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.dcbe3484.chunk.js"
  },
  {
    "revision": "4215145f8de1c86dce04f91f2e04b52d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.dcbe3484.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fefdb2b32b93c1920708",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.1caaa299.chunk.js"
  },
  {
    "revision": "9d0800bdca3115c11b65",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.22807818.js"
  },
  {
    "revision": "19a5bdabd660fde16554c866e650eadc",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/media/icon-back.19a5bdab.svg"
  }
]);